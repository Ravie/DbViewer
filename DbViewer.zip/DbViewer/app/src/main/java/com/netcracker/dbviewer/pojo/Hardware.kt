package com.netcracker.dbviewer.pojo

data class Hardware(
    val id: Long,
    val name: String,
    val service_id: Long,
    val serial: String,
    val hardware_status_id: Long,
    val address_id: Long
)