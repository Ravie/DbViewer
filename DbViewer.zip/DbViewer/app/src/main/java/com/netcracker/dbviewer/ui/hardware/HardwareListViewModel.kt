package com.netcracker.dbviewer.ui.hardware

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HardwareListViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is hw list Fragment"
    }
    val text: LiveData<String> = _text
}