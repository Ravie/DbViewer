package com.netcracker.dbviewer.services

import com.netcracker.dbviewer.pojo.Customer
import io.reactivex.Observable
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface RestApiService {

    @GET("customers")
    fun searchCustomers(): Observable<List<Customer>>

    @GET("customers/search/getCustomerByPhoneNumber")
    fun searchCustomerByPhoneNumber(@Query("phoneNumber") phoneNumber: Long): Observable<List<Customer>>

    companion object Factory {
        fun create(): RestApiService {
            val retrofit = Retrofit.Builder()
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://mk-nc.herokuapp.com/")
                .build()

            return retrofit.create(RestApiService::class.java);
        }
    }
}