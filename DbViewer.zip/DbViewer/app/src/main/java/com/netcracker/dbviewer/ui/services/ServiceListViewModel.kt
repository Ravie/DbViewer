package com.netcracker.dbviewer.ui.services

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.netcracker.dbviewer.pojo.Service
import com.netcracker.dbviewer.services.RestApiService
import com.netcracker.dbviewer.services.SearchRepositoryProvider
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ServiceListViewModel : ViewModel() {
    private val services: MutableLiveData<List<Service>> by lazy {
        MutableLiveData().also {
            loadServices()
        }
    }

    fun getServices(): LiveData<List<Service>> {
        return services
    }

    private fun loadServices() {
        val apiService = RestApiService.create()
        val repository = SearchRepositoryProvider.provideSearchRepository(apiService)
        val disposable = repository.searchServices()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .subscribe({ result ->
                services = result
            }, { error ->
                Log.d("Error", error.message.orEmpty())
            })
        disposable.dispose()
    }
}