package com.netcracker.dbviewer.pojo

data class Service(
    val id: Long,
    val name: String,
    val customer_id: Long,
    val service_status_id: Long
)