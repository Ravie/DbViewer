package com.netcracker.dbviewer.pojo

data class Customer(
    val id: Long,
    val first_name: String,
    val last_name: String,
    val phone_number: Long,
    val customer_status_id: Long
)