package com.netcracker.dbviewer.ui.customers

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.netcracker.dbviewer.pojo.Customer
import com.netcracker.dbviewer.services.RestApiService
import com.netcracker.dbviewer.services.SearchRepositoryProvider
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class CustomerListViewModel : ViewModel() {
    private val customers: MutableLiveData<List<Customer>> by lazy {
        MutableLiveData().also {
            loadCustomers()
        }
    }
    private val apiService = RestApiService.create()
    private val repository = SearchRepositoryProvider.provideSearchRepository(apiService)

    fun getCustomers(): LiveData<List<Customer>> {
        return customers
    }

    private fun loadCustomers() {
        val disposable = repository.searchCustomers()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .subscribe({ result ->
                customers.value = result
            }, { error ->
                Log.d("Error", error.message.orEmpty())
            })
        disposable.dispose()
    }
}
