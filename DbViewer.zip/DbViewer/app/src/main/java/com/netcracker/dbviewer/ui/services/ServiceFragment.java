package com.netcracker.dbviewer.ui.services;

import android.app.Fragment;

public class ServiceFragment extends Fragment {
}
