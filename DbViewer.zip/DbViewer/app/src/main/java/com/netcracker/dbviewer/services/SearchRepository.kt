package com.netcracker.dbviewer.services

import com.netcracker.dbviewer.pojo.Customer
import io.reactivex.Observable

object SearchRepositoryProvider {
    fun provideSearchRepository(apiService: RestApiService): SearchRepository {
        return SearchRepository(apiService)
    }
}

class SearchRepository(private val apiService: RestApiService) {
    fun searchCustomers(): Observable<List<Customer>> {
        return apiService.searchCustomers()
    }

    fun searchCustomerByPhoneNumber(phoneNumber: Long): Observable<List<Customer>> {
        return apiService.searchCustomerByPhoneNumber(phoneNumber)
    }
}