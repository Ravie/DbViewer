package com.netcracker.dbviewer.ui.customers;

import android.app.Fragment;

public class CustomerFragment extends Fragment {
}
