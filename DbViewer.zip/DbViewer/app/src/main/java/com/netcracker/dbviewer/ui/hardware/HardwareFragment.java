package com.netcracker.dbviewer.ui.hardware;

import android.app.Fragment;

public class HardwareFragment extends Fragment {
}
