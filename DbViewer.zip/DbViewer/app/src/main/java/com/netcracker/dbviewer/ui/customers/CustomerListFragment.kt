package com.netcracker.dbviewer.ui.customers

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.netcracker.dbviewer.R
import com.netcracker.dbviewer.pojo.Customer
import kotlinx.android.synthetic.main.fragment_customer_list.*

class CustomerListFragment : Fragment() {

    private val mNicolasCageMovies = listOf(
        Customer(1, "r", "p", 1234, 1)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_customer_list, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        customer_recycle_view.apply {
            layoutManager = LinearLayoutManager(activity)
            adapter = CustomerListAdapter(mNicolasCageMovies)
        }
    }

    companion object {
        fun newInstance(): CustomerListFragment = CustomerListFragment()

    }
}
