package com.netcracker.dbviewer.ui.hardware

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.netcracker.dbviewer.R

class HardwareListFragment : Fragment() {

    private lateinit var hardwareListViewModel: HardwareListViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        hardwareListViewModel =
                ViewModelProviders.of(this).get(HardwareListViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_hardware_list, container, false)
        val textView: TextView = root.findViewById(R.id.text_hardware_list)
        hardwareListViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })
        return root
    }
}
